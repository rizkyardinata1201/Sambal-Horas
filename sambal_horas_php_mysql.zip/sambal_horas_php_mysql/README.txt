CARA MENJALANKAN WEBSITE SAMBAL HORAS PHP + MYSQL

1. Install dan buka XAMPP.
2. Start Apache dan MySQL.
3. Copy folder sambal_horas_php_mysql ke:
   C:\xampp\htdocs\
4. Buka browser: http://localhost/phpmyadmin
5. Klik tab SQL, lalu paste isi file database.sql.
6. Klik Go / Kirim.
7. Buka website: http://localhost/sambal_horas_php_mysql/index.php
8. Login admin: http://localhost/sambal_horas_php_mysql/login-admin.php

Username: admin
Password: horas123

Masukkan gambar ke folder img:
logo1.png, kacepeh.jpeg, teri.jpeg, cumi.jpeg, andaliman.jpeg
